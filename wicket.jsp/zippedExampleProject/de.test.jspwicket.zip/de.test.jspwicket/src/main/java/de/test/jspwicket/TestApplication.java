package de.test.jspwicket;

import org.apache.wicket.Page;
import org.apache.wicket.protocol.http.WebApplication;

import wicket.jsp.WicketServletAndJSPResolver;

public class TestApplication extends WebApplication {

    @Override
    public Class<? extends Page> getHomePage() {
	return TestPage.class;
    }

    @Override
    protected void init() {
	super.init();
	getPageSettings().addComponentResolver(
		new WicketServletAndJSPResolver());
	getMarkupSettings().setStripWicketTags(true);
    }
}
