package de.test.jspwicket;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.request.cycle.RequestCycle;
import org.apache.wicket.request.mapper.parameter.PageParameters;

public class TestPage2 extends WebPage {

    private static final long serialVersionUID = 3697359532920487023L;

    public TestPage2(PageParameters parameters){
	System.err.println(RequestCycle.get().getRequest().getPostParameters().getParameterValue("hiddenparam"));
	System.err.println(parameters.get("hiddenparam").toString()); 
    }
}
