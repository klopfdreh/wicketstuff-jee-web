package de.test.jspwicket;

import org.apache.wicket.ajax.WicketAjaxJQueryResourceReference;
import org.apache.wicket.ajax.WicketEventJQueryResourceReference;
import org.apache.wicket.markup.head.IHeaderResponse;
import org.apache.wicket.markup.head.JavaScriptHeaderItem;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.BookmarkablePageLink;
import org.apache.wicket.resource.JQueryResourceReference;

public class TestPage extends WebPage {

    private static final long serialVersionUID = 1457592847439107204L;

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public TestPage() {
	add(new Label("test", "test"));
	add(new BookmarkablePageLink("link", TestPage2.class));
    }

    @Override
    public void renderHead(IHeaderResponse response) {
	response.render(JavaScriptHeaderItem
		.forReference(JQueryResourceReference.get()));
	response.render(JavaScriptHeaderItem
		.forReference(WicketEventJQueryResourceReference.get()));
	response.render(JavaScriptHeaderItem
		.forReference(WicketAjaxJQueryResourceReference.get()));
    }
}
